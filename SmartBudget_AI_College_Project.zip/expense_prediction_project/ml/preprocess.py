import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ['date','category','amount','description','payment_method','monthly_income']
FEATURES = ['lag_1','lag_2','lag_3','rolling_mean_3','trend','monthly_income','month_number']


def clean_expenses(df):
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f'Missing required columns: {", ".join(missing)}')
    out = df.copy()
    out['date'] = pd.to_datetime(out['date'], errors='coerce')
    out['amount'] = pd.to_numeric(out['amount'], errors='coerce')
    out['monthly_income'] = pd.to_numeric(out['monthly_income'], errors='coerce')
    out = out.dropna(subset=['date','amount','monthly_income'])
    out = out[out['amount'] >= 0]
    out['category'] = out['category'].astype(str).str.strip().str.title()
    return out


def monthly_feature_frame(df):
    df = clean_expenses(df)
    monthly = (df.assign(month=df['date'].dt.to_period('M').astype(str))
               .groupby('month', as_index=False)
               .agg(total_expense=('amount','sum'), monthly_income=('monthly_income','mean')))
    monthly['month_number'] = pd.to_datetime(monthly['month']).dt.month
    monthly['lag_1'] = monthly['total_expense'].shift(1)
    monthly['lag_2'] = monthly['total_expense'].shift(2)
    monthly['lag_3'] = monthly['total_expense'].shift(3)
    monthly['rolling_mean_3'] = monthly['total_expense'].shift(1).rolling(3).mean()
    monthly['trend'] = (monthly['lag_1'] - monthly['lag_3']) / 2
    monthly['target'] = monthly['total_expense'].shift(-1)
    return monthly.dropna(subset=FEATURES + ['target']).reset_index(drop=True)


def features_for_next_prediction(monthly_totals, income, target_month_number):
    values = list(monthly_totals)[-3:]
    if len(values) < 3:
        raise ValueError('At least 3 completed monthly expense totals are required.')
    lag_1, lag_2, lag_3 = values[-1], values[-2], values[-3]
    rolling = float(np.mean(values))
    trend = (lag_1 - lag_3) / 2
    return pd.DataFrame([{
        'lag_1': lag_1, 'lag_2': lag_2, 'lag_3': lag_3,
        'rolling_mean_3': rolling, 'trend': trend,
        'monthly_income': income, 'month_number': target_month_number
    }], columns=FEATURES)
