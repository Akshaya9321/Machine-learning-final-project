from pathlib import Path
import sys
import json
BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from ml.preprocess import FEATURES, monthly_feature_frame

DATA_PATH = BASE / 'data' / 'expenses.csv'
MODEL_PATH = BASE / 'models' / 'expense_prediction_model.pkl'
METRICS_PATH = BASE / 'models' / 'model_metrics.json'


def metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    return {'MAE': float(mean_absolute_error(y_true, y_pred)), 'MSE': float(mse),
            'RMSE': float(mse ** 0.5), 'R2': float(r2_score(y_true, y_pred))}


def train():
    df = pd.read_csv(DATA_PATH)
    frame = monthly_feature_frame(df)
    if len(frame) < 6:
        raise ValueError('Need at least 6 feature rows for chronological evaluation.')
    split = max(3, int(len(frame) * 0.8))
    if split >= len(frame): split = len(frame) - 1
    X_train, X_test = frame[FEATURES].iloc[:split], frame[FEATURES].iloc[split:]
    y_train, y_test = frame['target'].iloc[:split], frame['target'].iloc[split:]
    models = {
        'Linear Regression': LinearRegression(),
        'Random Forest Regressor': RandomForestRegressor(n_estimators=250, random_state=42, min_samples_leaf=1)
    }
    results = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        results[name] = metrics(y_test, model.predict(X_test))
    # Choose by lowest MAE; this is a factual metric-based selection, not a hard-coded claim.
    selected_name = min(results, key=lambda n: results[n]['MAE'])
    selected = models[selected_name]
    selected.fit(frame[FEATURES], frame['target'])
    MODEL_PATH.parent.mkdir(exist_ok=True)
    joblib.dump({'model': selected, 'features': FEATURES, 'model_name': selected_name}, MODEL_PATH)
    payload = {'selected_model': selected_name, 'training_records': len(X_train), 'testing_records': len(X_test), 'metrics': results}
    METRICS_PATH.write_text(json.dumps(payload, indent=2))
    print(json.dumps(payload, indent=2))
    return payload


if __name__ == '__main__':
    train()
