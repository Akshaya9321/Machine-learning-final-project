import json
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
path=BASE/'models'/'model_metrics.json'
if not path.exists():
    print('No metrics file found. Run python ml/train_model.py first.')
else:
    print(json.dumps(json.loads(path.read_text()), indent=2))
