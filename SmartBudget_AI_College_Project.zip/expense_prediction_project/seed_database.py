from datetime import date
from pathlib import Path
import pandas as pd
from app import create_app
from database.models import db, User, Expense, Budget

app = create_app()
CSV_PATH = Path(__file__).resolve().parent / 'data' / 'expenses.csv'

with app.app_context():
    db.drop_all(); db.create_all()
    user = User(name='Demo Student', email='demo@smartbudget.local', monthly_income=50000)
    user.set_password('Demo@123')
    db.session.add(user); db.session.flush()
    df = pd.read_csv(CSV_PATH)
    for _, r in df.tail(120).iterrows():
        db.session.add(Expense(user_id=user.id, date=date.fromisoformat(r['date']), category=r['category'],
                               amount=float(r['amount']), description=r['description'], payment_method=r['payment_method']))
    current = date.today().strftime('%Y-%m')
    db.session.add(Budget(user_id=user.id, month=current, category=None, amount=40000))
    for category, amount in [('Food',8000),('Transportation',4000),('Shopping',5000),('Entertainment',3000)]:
        db.session.add(Budget(user_id=user.id, month=current, category=category, amount=amount))
    db.session.commit()
    print('Seeded demo user: demo@smartbudget.local / Demo@123')
