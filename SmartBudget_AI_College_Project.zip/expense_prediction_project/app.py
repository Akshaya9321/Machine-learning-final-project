from pathlib import Path
from flask import Flask, render_template
from config import Config
from database.models import db
from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.expenses import expenses_bp
from routes.budgets import budgets_bp
from routes.analytics import analytics_bp
from routes.prediction import prediction_bp


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)

    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    db.init_app(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(expenses_bp)
    app.register_blueprint(budgets_bp)
    app.register_blueprint(analytics_bp)
    app.register_blueprint(prediction_bp)

    @app.errorhandler(404)
    def not_found(_):
        return render_template('404.html'), 404

    @app.errorhandler(500)
    def server_error(_):
        return render_template('500.html'), 500

    with app.app_context():
        db.create_all()

    return app


app = create_app()

if __name__ == '__main__':
    app.run(debug=True)
