from pathlib import Path
import json
import joblib
import pandas as pd
from sqlalchemy import func
from database.models import Expense
from ml.preprocess import features_for_next_prediction

BASE = Path(__file__).resolve().parents[1]
MODEL_PATH = BASE / 'models' / 'expense_prediction_model.pkl'
METRICS_PATH = BASE / 'models' / 'model_metrics.json'


def load_artifacts():
    if not MODEL_PATH.exists():
        raise FileNotFoundError('Trained model not found. Run: python ml/train_model.py')
    bundle = joblib.load(MODEL_PATH)
    metrics = json.loads(METRICS_PATH.read_text()) if METRICS_PATH.exists() else {}
    return bundle, metrics


def predict_user_expense(user):
    rows = (Expense.query.filter_by(user_id=user.id)
            .with_entities(func.strftime('%Y-%m', Expense.date), func.sum(Expense.amount))
            .group_by(func.strftime('%Y-%m', Expense.date))
            .order_by(func.strftime('%Y-%m', Expense.date)).all())
    monthly = [float(total or 0) for _, total in rows]
    if len(monthly) < 3:
        return {'available': False, 'message': 'At least 3 months of historical expense data are required for a prediction.'}
    last_month = pd.Period(rows[-1][0], freq='M')
    target_month = (last_month + 1).month
    bundle, metrics = load_artifacts()
    X = features_for_next_prediction(monthly, user.monthly_income, target_month)
    predicted = max(0.0, float(bundle['model'].predict(X)[0]))
    average = sum(monthly[-3:]) / 3
    change = ((predicted - average) / average * 100) if average else 0
    return {'available': True, 'prediction': predicted, 'average': average, 'change_pct': change,
            'expected_savings': user.monthly_income - predicted, 'model_name': bundle['model_name'], 'metrics': metrics}
