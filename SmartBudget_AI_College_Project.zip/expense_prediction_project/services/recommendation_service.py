def generate_recommendations(user, metrics, prediction, budget_rows):
    recs = []
    total = metrics['total']
    if prediction.get('available'):
        p = prediction['prediction']
        recs.append(f'If your current spending pattern continues, your estimated monthly expense is ₹{p:,.0f}.')
    if total > 0 and metrics['categories']:
        category, amount = max(metrics['categories'].items(), key=lambda x: x[1])
        pct = amount / total * 100
        recs.append(f'{category} spending accounts for {pct:.1f}% of your current-month expenses.')
    if metrics['trend'] != 'Stable':
        recs.append(f'Your spending trend is currently {metrics["trend"].lower()} based on the latest monthly totals.')
    for row in budget_rows:
        if row['category'] != 'Overall' and row['percentage'] >= 80:
            recs.append(f'{row["category"]} has used {row["percentage"]:.0f}% of its budget; review upcoming spending in this category.')
    if prediction.get('available') and prediction['expected_savings'] >= 0:
        recs.append(f'Projected savings are approximately ₹{prediction["expected_savings"]:,.0f} next month.')
    elif prediction.get('available'):
        recs.append('The projected expense is above your current monthly income; consider reviewing discretionary categories.')
    if not recs:
        recs.append('Add more expenses and budgets to unlock personalized spending recommendations.')
    return recs
