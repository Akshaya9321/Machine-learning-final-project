from collections import defaultdict
from datetime import date
from sqlalchemy import func
from database.models import Expense, Budget

CATEGORIES = ['Food','Transportation','Rent','Utilities','Shopping','Entertainment','Healthcare','Education','Groceries','Travel','Other']


def monthly_totals(user_id):
    rows = (Expense.query.with_entities(func.strftime('%Y-%m', Expense.date), func.sum(Expense.amount))
            .filter_by(user_id=user_id).group_by(func.strftime('%Y-%m', Expense.date))
            .order_by(func.strftime('%Y-%m', Expense.date)).all())
    return {month: float(total or 0) for month, total in rows}


def category_totals(user_id, month=None):
    q = Expense.query.filter_by(user_id=user_id)
    if month:
        q = q.filter(func.strftime('%Y-%m', Expense.date) == month)
    rows = q.with_entities(Expense.category, func.sum(Expense.amount)).group_by(Expense.category).all()
    return {category: float(total or 0) for category, total in rows}


def dashboard_metrics(user, current_month):
    cats = category_totals(user.id, current_month)
    total = sum(cats.values())
    months = monthly_totals(user.id)
    avg = sum(months.values()) / len(months) if months else 0
    savings = user.monthly_income - total
    savings_pct = (savings / user.monthly_income * 100) if user.monthly_income else 0
    highest = max(cats.items(), key=lambda x: x[1]) if cats else ('None', 0)
    trend = 'Stable'
    vals = list(months.values())
    if len(vals) >= 2:
        if vals[-1] > vals[-2] * 1.05: trend = 'Increasing'
        elif vals[-1] < vals[-2] * 0.95: trend = 'Decreasing'
    return {
        'total': total, 'avg': avg, 'savings': savings, 'savings_pct': savings_pct,
        'highest_category': highest[0], 'highest_category_amount': highest[1], 'trend': trend,
        'months': months, 'categories': cats
    }


def budget_rows(user_id, month):
    budgets = Budget.query.filter_by(user_id=user_id, month=month).all()
    actuals = category_totals(user_id, month)
    result = []
    overall = next((b for b in budgets if b.category is None), None)
    if overall:
        actual = sum(actuals.values())
        result.append({'category':'Overall', 'budget':overall.amount, 'actual':actual})
    for b in budgets:
        if b.category is not None:
            result.append({'category':b.category, 'budget':b.amount, 'actual':actuals.get(b.category, 0)})
    for row in result:
        row['remaining'] = row['budget'] - row['actual']
        row['percentage'] = (row['actual'] / row['budget'] * 100) if row['budget'] else 0
        row['status'] = 'Exceeded' if row['actual'] > row['budget'] else ('Warning' if row['percentage'] >= 80 else 'Safe')
    return result
