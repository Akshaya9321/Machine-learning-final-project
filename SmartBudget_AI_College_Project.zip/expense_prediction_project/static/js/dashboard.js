// Dashboard-specific behavior is rendered inline so chart data remains server-authenticated.
