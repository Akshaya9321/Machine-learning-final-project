// Shared Chart.js helpers can be added here as the application grows.
