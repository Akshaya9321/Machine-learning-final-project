document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('input[type=number]').forEach(i=>i.addEventListener('input',()=>{if(i.value<0)i.value=''}));});
