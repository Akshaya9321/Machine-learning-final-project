from tests.test_auth import app_client
from database.models import db

def test_budget_creation():
    c,app=app_client()
    with app.app_context(): db.drop_all(); db.create_all()
    c.post('/register',data={'name':'Test','email':'b@example.com','monthly_income':'50000','password':'secret1'})
    c.post('/login',data={'email':'b@example.com','password':'secret1'})
    r=c.post('/budgets',data={'month':'2026-09','category':'Food','amount':'8000'},follow_redirects=True)
    assert b'Budget saved' in r.data
    assert b'Food' in r.data
