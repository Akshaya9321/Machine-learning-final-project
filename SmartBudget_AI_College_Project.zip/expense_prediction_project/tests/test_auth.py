import tempfile
from app import create_app
from database.models import db, User

def app_client():
    path=tempfile.mktemp(suffix='.db')
    app=create_app({'TESTING':True,'SQLALCHEMY_DATABASE_URI':f'sqlite:///{path}','SECRET_KEY':'test'})
    return app.test_client(), app

def test_register_and_login():
    c, app=app_client()
    with app.app_context(): db.drop_all(); db.create_all()
    r=c.post('/register',data={'name':'Test User','email':'test@example.com','monthly_income':'50000','password':'secret1'},follow_redirects=True)
    assert b'Registration successful' in r.data
    r=c.post('/login',data={'email':'test@example.com','password':'secret1'},follow_redirects=True)
    assert b'Dashboard' in r.data
