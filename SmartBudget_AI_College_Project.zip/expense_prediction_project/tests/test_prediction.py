from datetime import date
from tests.test_auth import app_client
from database.models import db, User, Expense

def test_prediction_route_needs_data_not_crash():
    c,app=app_client()
    with app.app_context():
        db.drop_all(); db.create_all()
        u=User(name='P',email='p@example.com',monthly_income=50000); u.set_password('secret1'); db.session.add(u); db.session.commit()
    c.post('/login',data={'email':'p@example.com','password':'secret1'})
    r=c.get('/prediction')
    assert r.status_code==200
    assert b'Prediction' in r.data

def test_unauthorized_access():
    c,app=app_client()
    with app.app_context(): db.drop_all(); db.create_all()
    assert c.get('/dashboard').status_code==302
    assert c.get('/api/prediction').status_code==302
