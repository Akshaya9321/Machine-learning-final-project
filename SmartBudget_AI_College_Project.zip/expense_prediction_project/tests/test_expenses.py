from tests.test_auth import app_client
from database.models import db

def login(c):
    c.post('/register',data={'name':'Test','email':'x@example.com','monthly_income':'50000','password':'secret1'})
    c.post('/login',data={'email':'x@example.com','password':'secret1'})

def test_expense_crud():
    c,app=app_client()
    with app.app_context(): db.drop_all(); db.create_all()
    login(c)
    r=c.post('/expenses/add',data={'date':'2026-09-01','category':'Food','amount':'500','description':'Lunch','payment_method':'UPI'},follow_redirects=True)
    assert b'Lunch' in r.data
    with app.app_context():
        from database.models import Expense
        e=Expense.query.first(); eid=e.id
    r=c.post(f'/expenses/edit/{eid}',data={'date':'2026-09-01','category':'Food','amount':'600','description':'Dinner','payment_method':'UPI'},follow_redirects=True)
    assert b'Dinner' in r.data
    r=c.post(f'/expenses/delete/{eid}',follow_redirects=True)
    assert b'Expense deleted' in r.data
