from datetime import date
from flask import Blueprint, flash, redirect, render_template, request, url_for
from database.models import db, Budget
from routes.auth import current_user
from routes.dashboard import login_required
from routes.expenses import CATEGORIES

budgets_bp = Blueprint('budgets', __name__)

@budgets_bp.route('/budgets', methods=['GET','POST'])
@login_required
def budgets():
    user = current_user()
    month = request.args.get('month') or date.today().strftime('%Y-%m')
    if request.method == 'POST':
        month = request.form.get('month', month)
        category = request.form.get('category', '').strip() or None
        try: amount = float(request.form.get('amount', ''))
        except ValueError: amount = 0
        if not amount > 0:
            flash('Budget amount must be positive.', 'danger')
        elif category and category not in CATEGORIES:
            flash('Invalid category.', 'danger')
        else:
            existing = Budget.query.filter_by(user_id=user.id, month=month, category=category).first()
            if existing: existing.amount = amount
            else: db.session.add(Budget(user_id=user.id, month=month, category=category, amount=amount))
            db.session.commit()
            flash('Budget saved.', 'success')
        return redirect(url_for('budgets.budgets', month=month))
    rows = __import__('services.analytics_service', fromlist=['budget_rows']).budget_rows(user.id, month)
    return render_template('budgets.html', rows=rows, month=month, categories=CATEGORIES)

@budgets_bp.post('/budgets/delete/<int:budget_id>')
@login_required
def delete_budget(budget_id):
    budget = Budget.query.filter_by(id=budget_id, user_id=current_user().id).first_or_404()
    month = budget.month
    db.session.delete(budget); db.session.commit()
    flash('Budget deleted.', 'info')
    return redirect(url_for('budgets.budgets', month=month))
