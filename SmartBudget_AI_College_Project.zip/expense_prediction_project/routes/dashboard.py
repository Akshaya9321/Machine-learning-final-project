from datetime import date
from flask import Blueprint, jsonify, redirect, render_template, session, url_for
from sqlalchemy import func
from database.models import db, User, Expense
from routes.auth import current_user
from services.analytics_service import dashboard_metrics, budget_rows
from services.prediction_service import predict_user_expense
from services.recommendation_service import generate_recommendations

dashboard_bp = Blueprint('dashboard', __name__)


def login_required(view):
    from functools import wraps
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            return redirect(url_for('auth.login'))
        return view(*args, **kwargs)
    return wrapped


@dashboard_bp.route('/dashboard')
@login_required
def dashboard():
    user = current_user()
    month = date.today().strftime('%Y-%m')
    metrics = dashboard_metrics(user, month)
    try:
        prediction = predict_user_expense(user)
    except Exception as exc:
        prediction = {'available': False, 'message': str(exc)}
    rows = budget_rows(user.id, month)
    recommendations = generate_recommendations(user, metrics, prediction, rows)
    return render_template('dashboard.html', user=user, metrics=metrics, prediction=prediction,
                           recommendations=recommendations, budget_rows=rows, current_month=month)


@dashboard_bp.route('/api/dashboard-data')
@login_required
def dashboard_data():
    user = current_user()
    month = date.today().strftime('%Y-%m')
    m = dashboard_metrics(user, month)
    return jsonify({'categories': m['categories'], 'months': m['months'], 'income': user.monthly_income})
