from flask import Blueprint, jsonify, render_template
from routes.auth import current_user
from routes.dashboard import login_required
from services.prediction_service import predict_user_expense

prediction_bp = Blueprint('prediction', __name__)

@prediction_bp.route('/prediction')
@login_required
def prediction():
    user = current_user()
    try: result = predict_user_expense(user)
    except Exception as exc: result = {'available': False, 'message': str(exc)}
    return render_template('prediction.html', result=result, user=user)

@prediction_bp.route('/api/prediction')
@login_required
def prediction_api():
    try: return jsonify(predict_user_expense(current_user()))
    except Exception as exc: return jsonify({'available': False, 'message': str(exc)}), 503
