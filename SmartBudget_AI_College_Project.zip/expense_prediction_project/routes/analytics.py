from datetime import date
from flask import Blueprint, jsonify, render_template, request
from sqlalchemy import func
from database.models import Expense
from routes.auth import current_user
from routes.dashboard import login_required
from services.analytics_service import dashboard_metrics, category_totals, monthly_totals

analytics_bp = Blueprint('analytics', __name__)

@analytics_bp.route('/analytics')
@login_required
def analytics():
    user = current_user(); month = request.args.get('month') or date.today().strftime('%Y-%m')
    m = dashboard_metrics(user, month)
    days = date.today().day if month == date.today().strftime('%Y-%m') else 30
    avg_daily = m['total'] / days if days else 0
    highest = Expense.query.filter_by(user_id=user.id).order_by(Expense.amount.desc()).first()
    return render_template('analytics.html', metrics=m, month=month, avg_daily=avg_daily, highest=highest)

@analytics_bp.route('/api/category-expenses')
@login_required
def category_expenses_api():
    return jsonify(category_totals(current_user().id, request.args.get('month')))

@analytics_bp.route('/api/monthly-expenses')
@login_required
def monthly_expenses_api():
    return jsonify(monthly_totals(current_user().id))
