import re
from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from database.models import db, User

auth_bp = Blueprint('auth', __name__)
EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


def current_user():
    user_id = session.get('user_id')
    return db.session.get(User, user_id) if user_id else None


@auth_bp.route('/')
def home():
    return redirect(url_for('dashboard.dashboard') if current_user() else url_for('auth.login'))


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user():
        return redirect(url_for('dashboard.dashboard'))
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        income_raw = request.form.get('monthly_income', '').strip()
        errors = []
        try:
            income = float(income_raw)
        except ValueError:
            income = 0
        if not name:
            errors.append('Full name is required.')
        if not EMAIL_RE.match(email):
            errors.append('Enter a valid email address.')
        if len(password) < 6:
            errors.append('Password must be at least 6 characters.')
        if income <= 0:
            errors.append('Monthly income must be positive.')
        if User.query.filter_by(email=email).first():
            errors.append('An account with this email already exists.')
        if errors:
            for error in errors:
                flash(error, 'danger')
            return render_template('register.html')
        user = User(name=name, email=email, monthly_income=income)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('auth.login'))
    return render_template('register.html')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user():
        return redirect(url_for('dashboard.dashboard'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            session.clear()
            session['user_id'] = user.id
            flash(f'Welcome back, {user.name.split()[0]}!', 'success')
            return redirect(url_for('dashboard.dashboard'))
        flash('Invalid email or password.', 'danger')
    return render_template('login.html')


@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))


@auth_bp.route('/profile', methods=['GET', 'POST'])
def profile():
    user = current_user()
    if not user:
        return redirect(url_for('auth.login'))
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        income_raw = request.form.get('monthly_income', '').strip()
        try:
            income = float(income_raw)
        except ValueError:
            income = 0
        if not name or income <= 0:
            flash('Name and positive monthly income are required.', 'danger')
        else:
            user.name = name
            user.monthly_income = income
            db.session.commit()
            flash('Profile updated.', 'success')
            return redirect(url_for('auth.profile'))
    return render_template('profile.html', user=user)
