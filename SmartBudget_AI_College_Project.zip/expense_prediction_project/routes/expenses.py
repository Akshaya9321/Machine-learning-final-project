from datetime import date
from flask import Blueprint, flash, redirect, render_template, request, url_for
from sqlalchemy import or_
from database.models import db, Expense
from routes.auth import current_user
from routes.dashboard import login_required

expenses_bp = Blueprint('expenses', __name__)
CATEGORIES = ['Food','Transportation','Rent','Utilities','Shopping','Entertainment','Healthcare','Education','Groceries','Travel','Other']
PAYMENTS = ['Cash','Credit Card','Debit Card','UPI','Bank Transfer','Other']


def parse_expense_form():
    errors = []
    try:
        amount = float(request.form.get('amount', ''))
    except ValueError:
        amount = 0
    try:
        expense_date = date.fromisoformat(request.form.get('date', ''))
    except ValueError:
        expense_date = None
    category = request.form.get('category', '').strip()
    payment = request.form.get('payment_method', '').strip()
    description = request.form.get('description', '').strip()
    if not expense_date: errors.append('A valid date is required.')
    if category not in CATEGORIES: errors.append('Choose a valid category.')
    if amount <= 0: errors.append('Amount must be greater than zero.')
    if payment not in PAYMENTS: errors.append('Choose a valid payment method.')
    return expense_date, category, amount, description, payment, errors


@expenses_bp.route('/expenses')
@login_required
def expenses():
    user = current_user()
    q = Expense.query.filter_by(user_id=user.id)
    search = request.args.get('search', '').strip()
    category = request.args.get('category', '').strip()
    date_filter = request.args.get('date', '').strip()
    if search:
        q = q.filter(or_(Expense.description.ilike(f'%{search}%'), Expense.category.ilike(f'%{search}%')))
    if category in CATEGORIES: q = q.filter_by(category=category)
    if date_filter:
        q = q.filter(Expense.date == date_filter)
    items = q.order_by(Expense.date.desc(), Expense.id.desc()).all()
    return render_template('expenses.html', expenses=items, categories=CATEGORIES, search=search, category=category, date_filter=date_filter)


@expenses_bp.route('/expenses/add', methods=['GET','POST'])
@login_required
def add_expense():
    if request.method == 'POST':
        parsed = parse_expense_form()
        expense_date, category, amount, description, payment, errors = parsed
        if errors:
            for e in errors: flash(e, 'danger')
            return render_template('add_expense.html', categories=CATEGORIES, payments=PAYMENTS)
        db.session.add(Expense(user_id=current_user().id, date=expense_date, category=category,
                               amount=amount, description=description, payment_method=payment))
        db.session.commit()
        flash('Expense added successfully.', 'success')
        return redirect(url_for('expenses.expenses'))
    return render_template('add_expense.html', categories=CATEGORIES, payments=PAYMENTS)


@expenses_bp.route('/expenses/edit/<int:expense_id>', methods=['GET','POST'])
@login_required
def edit_expense(expense_id):
    expense = Expense.query.filter_by(id=expense_id, user_id=current_user().id).first_or_404()
    if request.method == 'POST':
        expense_date, category, amount, description, payment, errors = parse_expense_form()
        if errors:
            for e in errors: flash(e, 'danger')
        else:
            expense.date, expense.category, expense.amount = expense_date, category, amount
            expense.description, expense.payment_method = description, payment
            db.session.commit()
            flash('Expense updated.', 'success')
            return redirect(url_for('expenses.expenses'))
    return render_template('edit_expense.html', expense=expense, categories=CATEGORIES, payments=PAYMENTS)


@expenses_bp.post('/expenses/delete/<int:expense_id>')
@login_required
def delete_expense(expense_id):
    expense = Expense.query.filter_by(id=expense_id, user_id=current_user().id).first_or_404()
    db.session.delete(expense)
    db.session.commit()
    flash('Expense deleted.', 'info')
    return redirect(url_for('expenses.expenses'))
